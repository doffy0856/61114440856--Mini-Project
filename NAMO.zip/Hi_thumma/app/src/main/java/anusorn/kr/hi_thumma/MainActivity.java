package anusorn.kr.hi_thumma;

import android.content.Intent;
import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
ImageButton S1;
MediaPlayer Ksound;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Ksound = MediaPlayer.create(MainActivity.this, R.raw.rakung);


        S1 = (ImageButton) findViewById(R.id.starty);
        S1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent ss = new Intent(MainActivity.this,pathum01.class);
                startActivity(ss);
                Ksound.start();


            }
        });


    }

}
