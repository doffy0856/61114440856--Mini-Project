package anusorn.kr.hi_thumma;

import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class P_night02 extends AppCompatActivity {
    TextView E1;
    Typeface R1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_p_night02);
        setContentView(R.layout.activity_p_night02);
        E1 = (TextView) findViewById(R.id.n1_nigth);
        R1 = Typeface.createFromAsset(getAssets(),"mac01.ttf");
        E1.setTypeface(R1);

    }
}
