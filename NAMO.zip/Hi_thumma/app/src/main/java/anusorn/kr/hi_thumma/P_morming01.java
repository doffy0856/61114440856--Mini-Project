package anusorn.kr.hi_thumma;

import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class P_morming01 extends AppCompatActivity {
 TextView Q1;
 Typeface W1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_p_morming01);
        Q1 = (TextView) findViewById(R.id.m1_morning);
        W1 = Typeface.createFromAsset(getAssets(),"mac01.ttf");
        Q1.setTypeface(W1);




    }
}
