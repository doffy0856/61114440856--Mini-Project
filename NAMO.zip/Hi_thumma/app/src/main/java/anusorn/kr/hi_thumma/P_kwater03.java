package anusorn.kr.hi_thumma;

import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class P_kwater03 extends AppCompatActivity {
    TextView U1;
    Typeface I1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_p_kwater03);
        U1 = (TextView) findViewById(R.id.m1_morning);
        I1 = Typeface.createFromAsset(getAssets(),"mac01.ttf");
        U1.setTypeface(I1);
    }
}
