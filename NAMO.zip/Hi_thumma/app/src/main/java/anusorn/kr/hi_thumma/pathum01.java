package anusorn.kr.hi_thumma;

import android.content.Intent;
import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

public class pathum01 extends AppCompatActivity {
ImageButton B1;
TextView Menu;
Button M,M1,M2,M3,M4,M5;
Typeface Tz,T,T1,T2,T3,T4,T5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pathum01);
        Menu = (TextView) findViewById(R.id.textView);
        Tz = Typeface.createFromAsset(getAssets(),"aa1.ttf");
        Menu.setTypeface(Tz);

        M = (Button) findViewById(R.id.button);
        T = Typeface.createFromAsset(getAssets(),"thai.ttf");
        M.setTypeface(T);

        M1 = (Button) findViewById(R.id.button2);
        T1 = Typeface.createFromAsset(getAssets(),"thai.ttf");
        M1.setTypeface(T1);

        M2 = (Button) findViewById(R.id.button3);
        T2 = Typeface.createFromAsset(getAssets(),"thai.ttf");
        M2.setTypeface(T1);

        M3 = (Button) findViewById(R.id.button4);
        T3 = Typeface.createFromAsset(getAssets(),"thai.ttf");
        M3.setTypeface(T3);

        M4 = (Button) findViewById(R.id.button5);
        T4 = Typeface.createFromAsset(getAssets(),"thai.ttf");
        M4.setTypeface(T4);

        M5 = (Button) findViewById(R.id.button6);
        T5 = Typeface.createFromAsset(getAssets(),"thai.ttf");
        M5.setTypeface(T5);




        Button Mo = (Button) findViewById(R.id.button);
        Mo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent mo = new Intent(pathum01.this, P_morming01.class);
                startActivity(mo);
            }
        });

        Button Ni = (Button) findViewById(R.id.button2);
        Ni.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent ni = new Intent(pathum01.this, P_night02.class);
                startActivity(ni);
            }
        });

        Button Kw = (Button) findViewById(R.id.button3);
        Kw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent kw = new Intent(pathum01.this, P_kwater03.class);
                startActivity(kw);
            }
        });

        Button Me = (Button) findViewById(R.id.button4);
        Me.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent me = new Intent(pathum01.this, P_metta04.class);
                startActivity(me);
            }
        });

        Button Ca = (Button) findViewById(R.id.button5);
        Ca.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent ca = new Intent(pathum01.this, P_catitum05.class);
                startActivity(ca);
            }
        });

        Button Du = (Button) findViewById(R.id.button6);
        Du.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent du = new Intent(pathum01.this, P_duduong06.class);
                startActivity(du);
            }
        });

        B1 = (ImageButton) findViewById(R.id.back);
        B1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent bb = new Intent(pathum01.this, MainActivity.class);
                startActivity(bb);
                finish();
            }
        });


    }
}
