package anusorn.kr.hi_thumma;

import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class P_catitum05 extends AppCompatActivity {
    TextView O1;
    Typeface P1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_p_catitum05);
        O1 = (TextView) findViewById(R.id.m1_morning);
        P1 = Typeface.createFromAsset(getAssets(),"mac01.ttf");
        O1.setTypeface(P1);
    }
}
