package anusorn.kr.hi_thumma;

import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class P_metta04 extends AppCompatActivity {
    TextView T1;
    Typeface Y1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_p_metta04);
        T1 = (TextView) findViewById(R.id.m1_morning);
        Y1 = Typeface.createFromAsset(getAssets(),"mac01.ttf");
        T1.setTypeface(Y1);

    }
}
