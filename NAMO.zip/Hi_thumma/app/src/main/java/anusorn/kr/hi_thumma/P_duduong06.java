package anusorn.kr.hi_thumma;

import android.content.Intent;
import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Random;

public class P_duduong06 extends AppCompatActivity {
TextView A1;
ImageButton Ba1;
Button D1,D2,D3,D4,D5,D6,D7;
Typeface B1,W1,W2,W3,W4,W5,W6,W7;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_p_duduong06);

        A1 = (TextView) findViewById(R.id.tvdodung);
        B1 = Typeface.createFromAsset(getAssets(),"aa1.ttf");
        A1.setTypeface(B1);

        D1 = (Button) findViewById(R.id.btdodung);
        W1 = Typeface.createFromAsset(getAssets(),"thai.ttf");
        D1.setTypeface(W1);

        D2 = (Button) findViewById(R.id.btdodung2);
        W2 = Typeface.createFromAsset(getAssets(),"thai.ttf");
        D2.setTypeface(W2);

        D3 = (Button) findViewById(R.id.btdodung3);
        W3 = Typeface.createFromAsset(getAssets(),"thai.ttf");
        D3.setTypeface(W3);

        D4 = (Button) findViewById(R.id.btdodung4);
        W4 = Typeface.createFromAsset(getAssets(),"thai.ttf");
        D4.setTypeface(W4);

        D5 = (Button) findViewById(R.id.btdodung5);
        W5 = Typeface.createFromAsset(getAssets(),"thai.ttf");
        D5.setTypeface(W5);

        D6 = (Button) findViewById(R.id.btdodung6);
        W6 = Typeface.createFromAsset(getAssets(),"thai.ttf");
        D6.setTypeface(W6);

        D7 = (Button) findViewById(R.id.btdodung7);
        W7 = Typeface.createFromAsset(getAssets(),"thai.ttf");
        D7.setTypeface(W7);



        Button D1 = (Button) findViewById(R.id.btdodung);
        D1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent mon = new Intent(P_duduong06.this, dd_week.class);
                mon.putExtra("day","mon");
                startActivity(mon);
            }
        });

        Button D2 = (Button) findViewById(R.id.btdodung2);
        D2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent tur = new Intent(P_duduong06.this, dd_week.class);
                tur.putExtra("day","tur");
                startActivity(tur);
            }
        });

        Button D3 = (Button) findViewById(R.id.btdodung3);
        D3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent wen = new Intent(P_duduong06.this, dd_week.class);
                wen.putExtra("day","wen");
                startActivity(wen);
            }
        });

        Button D4 = (Button) findViewById(R.id.btdodung4);
        D4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent thu = new Intent(P_duduong06.this, dd_week.class);
                thu.putExtra("day","thu");
                startActivity(thu);
            }
        });

        Button D5 = (Button) findViewById(R.id.btdodung5);
        D5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent fri = new Intent(P_duduong06.this, dd_week.class);
                fri.putExtra("day","fri");
                startActivity(fri);
            }
        });

        Button D6 = (Button) findViewById(R.id.btdodung6);
        D6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent sat = new Intent(P_duduong06.this, dd_week.class);
                sat.putExtra("day","sat");
                startActivity(sat);
            }
        });

        Button D7 = (Button) findViewById(R.id.btdodung7);
        D7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent sun = new Intent(P_duduong06.this, dd_week.class);
                sun.putExtra("day","sun");
                startActivity(sun);
            }
        });



        Ba1 = (ImageButton) findViewById(R.id.bmenu);
        Ba1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent ba1 = new Intent(P_duduong06.this, pathum01.class);
                startActivity(ba1);
                finish();
            }
        });



    }

}
